/*
 * Instance header file for ATSAMD20J18
 *
 * Copyright (c) 2022 Microchip Technology Inc. and its subsidiaries.
 *
 * Subject to your compliance with these terms, you may use Microchip software and any derivatives
 * exclusively with Microchip products. It is your responsibility to comply with third party license
 * terms applicable to your use of third party software (including open source software) that may
 * accompany Microchip software.
 *
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY,
 * APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, INCIDENTAL OR CONSEQUENTIAL
 * LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF
 * MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO THE FULLEST EXTENT
 * ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT
 * EXCEED THE AMOUNT OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
 *
 */

/* file generated from device description version 2019-11-25T06:48:59Z */
#ifndef _SAMD20_TC7_INSTANCE_
#define _SAMD20_TC7_INSTANCE_


/* ========== Instance Parameter definitions for TC7 peripheral ========== */
#define TC7_CC8_NUM                              (2)        
#define TC7_CC16_NUM                             (2)        
#define TC7_CC32_NUM                             (2)        
#define TC7_DITHERING_EXT                        (0)        
#define TC7_GCLK_ID                              (22)       
#define TC7_MASTER                               (0)        
#define TC7_OW_NUM                               (2)        
#define TC7_PERIOD_EXT                           (0)        
#define TC7_SHADOW_EXT                           (0)        
#define TC7_INSTANCE_ID                          (79)       

#endif /* _SAMD20_TC7_INSTANCE_ */
