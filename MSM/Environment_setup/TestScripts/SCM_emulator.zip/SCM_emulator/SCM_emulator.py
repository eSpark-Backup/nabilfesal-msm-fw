#!/usr/bin/env python3
import serial
import time
import os

def main():
    uart_port = "COM5"     # Change to your COM port (e.g., COM4, COM5, etc.)
    baud_rate = 115200     # Change as needed
    packet_file = "packet" # File containing the packet data

    # Check if file exists
    if not os.path.exists(packet_file):
        print(f"Error: File '{packet_file}' not found.")
        return

    try:
        # Read packet from file
        with open(packet_file, "rb") as f:  # rb = read as raw bytes
            packet = f.read()

        if not packet:
            print("Error: Packet file is empty.")
            return

        # Open serial connection
        ser = serial.Serial(uart_port, baud_rate, timeout=0.5)
        print(f"Opened UART on {uart_port} at {baud_rate} baud.")
        print(f"Loaded packet ({len(packet)} bytes): {packet}")

        # Send packet in a loop
        while True:
            # Send
            ser.write(packet)
            # print(f"Sent ({len(packet)} bytes): {packet}")

            # Read response (if any)
            response = ser.read_all()
            if response:
                print(f"Received ({len(response)} bytes): {response}")

            time.sleep(0.1)  # Send every second

    except serial.SerialException as e:
        print(f"Error: {e}")

    except KeyboardInterrupt:
        print("\nStopped by user.")

if __name__ == "__main__":
    main()
